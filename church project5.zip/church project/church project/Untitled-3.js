// ====== Mobile nav toggle ======
const navToggle = document.getElementById("nav-toggle");
const navLinks = document.getElementById("nav-links");

navToggle.addEventListener("click", () => {
  navLinks.classList.toggle("open");
});

// Close mobile nav when a link is clicked
document.querySelectorAll(".nav-link").forEach((link) => {
  link.addEventListener("click", () => {
    navLinks.classList.remove("open");
  });
});

// ====== Active link on scroll (basic) ======
const sections = document.querySelectorAll("section[id]");
const navItems = document.querySelectorAll(".nav-link");

function onScroll() {
  const scrollY = window.pageYOffset;

  sections.forEach((section) => {
    const rect = section.getBoundingClientRect();
    const offsetTop = rect.top + window.pageYOffset - 120;
    const offsetBottom = offsetTop + section.offsetHeight;
    const id = section.getAttribute("id");

    if (scrollY >= offsetTop && scrollY < offsetBottom) {
      navItems.forEach((item) => item.classList.remove("active"));
      const current = document.querySelector(`.nav-link[href="#${id}"]`);
      if (current) current.classList.add("active");
    }
  });
}

window.addEventListener("scroll", onScroll);

// ====== Character counter ======
const messageField = document.getElementById("message");
const charCount = document.getElementById("charCount");

if (messageField && charCount) {
  const updateCount = () => {
    charCount.textContent = messageField.value.length;
  };

  messageField.addEventListener("input", updateCount);
  updateCount();
}

// ====== Simple form handling (front-end only) ======
const contactForm = document.getElementById("contactForm");
const formStatus = document.getElementById("formStatus");

if (contactForm) {
  contactForm.addEventListener("submit", (e) => {
    e.preventDefault();

    if (!contactForm.checkValidity()) {
      contactForm.reportValidity();
      return;
    }

    // Fake success message (replace with real backend call)
    formStatus.textContent =
      "Thank you for your message! We'll get back to you soon.";
    contactForm.reset();
    if (charCount) charCount.textContent = "0";
  });
}